# BuildPath — API Design

**Status:** Approved — Day 2 (design only — no implementation yet)

BuildPath has two categories of "API":

1. **Custom serverless endpoints** (Vercel functions) — used only where the Gemini API key must stay server-side.
2. **Data operations** (Supabase client SDK, direct from frontend) — used for everything else, secured by Row-Level Security. These aren't hand-written endpoints, but they are still a contract the frontend relies on, so they're documented below with the same rigor.

No custom backend exists beyond the two serverless functions.

---

## Part A — Custom Serverless Endpoints

### 1. `POST /api/generate-plan`

**Purpose:** Takes intake data and returns an AI-generated, personalized task plan; persists it to the database.

- **Method:** POST
- **Auth:** Required. Supabase JWT passed in `Authorization: Bearer <token>` header. The function verifies the token server-side before doing anything.

**Request body:**
```json
{
  "idea_text": "A habit tracker app with streaks",
  "skill_level": "beginner",
  "time_available": "3-4 hrs/day",
  "preferences": "Prefer JavaScript, no backend experience"
}
```

**Validation (server-side, before calling Gemini):**
- `idea_text`: required, string, 5–500 chars
- `skill_level`: required, one of `beginner | intermediate | advanced`
- `time_available`: required, string, max 100 chars
- `preferences`: optional, string, max 300 chars
- Reject if the authenticated user already has a project row (enforces one-active-project rule at the API layer, in addition to the DB unique constraint)

**Response — success (201):**
```json
{
  "project": {
    "id": "uuid",
    "idea_text": "...",
    "skill_level": "beginner",
    "time_available": "3-4 hrs/day",
    "preferences": "..."
  },
  "tasks": [
    {
      "id": "uuid",
      "phase": "Setup",
      "title": "Initialize project repo",
      "description": "...",
      "order_index": 1,
      "requires_skill": false,
      "skill_reason": null
    }
  ]
}
```

**Error cases:**
| Status | Case |
|---|---|
| 401 | Missing/invalid auth token |
| 400 | Validation failed (bad input) |
| 409 | User already has an active project |
| 502 | Gemini API call failed or returned malformed JSON (after validation retry) |
| 500 | Database insert failed |

---

### 2. `POST /api/next-step`

**Purpose:** Given the current task state (and optional user note about confusion), returns a short, lightweight AI guidance response.

- **Method:** POST
- **Auth:** Required. Same JWT pattern as above.

**Request body:**
```json
{
  "project_id": "uuid",
  "tasks": [
    { "id": "uuid", "title": "Initialize project repo", "is_complete": true },
    { "id": "uuid", "title": "Set up database schema", "is_complete": false }
  ],
  "user_note": "I'm confused about how to connect the database"
}
```

**Validation:**
- `project_id`: required, must belong to the authenticated user (checked via RLS-equivalent server-side query)
- `tasks`: required, non-empty array
- `user_note`: optional, string, max 500 chars

**Response — success (200):**
```json
{
  "next_task_id": "uuid",
  "explanation": "Your next step is setting up the database schema. Since you mentioned confusion about connecting it, focus first on getting a single table created and readable before adding relationships.",
  "adjustment_note": "Consider reviewing Supabase's quickstart before continuing."
}
```

**Error cases:**
| Status | Case |
|---|---|
| 401 | Missing/invalid auth token |
| 400 | Validation failed |
| 404 | `project_id` not found or doesn't belong to user |
| 502 | Gemini API call failed or returned malformed JSON |

---

## Part B — Data Operations (Supabase client, direct from frontend)

These are not custom endpoints — they're `supabase-js` calls, protected by RLS policies (see `SCHEMA.md`). Documented here as a contract so the frontend implementation on later days has a clear spec.

### 3. Sign Up
- **Call:** `supabase.auth.signUp({ email, password })`
- **Auth:** None (this creates the session)
- **Validation:** Supabase enforces email format and minimum password length; frontend should also validate before calling.
- **Errors:** duplicate email, weak password — surfaced via Supabase's returned error object.

### 4. Log In
- **Call:** `supabase.auth.signInWithPassword({ email, password })`
- **Auth:** None (this creates the session)
- **Errors:** invalid credentials.

### 5. Log Out
- **Call:** `supabase.auth.signOut()`
- **Auth:** Requires active session.

### 6. Get Current Project
- **Call:** `supabase.from('projects').select('*').eq('user_id', userId).single()`
- **Auth:** RLS-enforced — only returns the caller's own row.
- **Response:** the project row, or `null` if none exists yet (used to decide whether to route to Intake or Dashboard).

### 7. Get Tasks for Project
- **Call:** `supabase.from('tasks').select('*').eq('project_id', projectId).order('order_index')`
- **Auth:** RLS-enforced via join to `projects.user_id`.

### 8. Toggle Task Completion
- **Call:** `supabase.from('tasks').update({ is_complete: newValue }).eq('id', taskId)`
- **Auth:** RLS-enforced.
- **Validation:** `taskId` must belong to a project owned by the caller (RLS handles this — an unauthorized update simply affects 0 rows).

---

## Notes for Implementation (Days 4–7)

- The two serverless functions are the **only** place the Gemini API key is referenced. It must be stored as a Vercel environment variable, never committed to the repo.
- All AI responses must be validated (`zod` schema) before being trusted or persisted — see `ARCHITECTURE.md` Section 5.
- No endpoint in v1.0 supports multi-project logic — every query assumes exactly one project per user, matching the DB constraint.
