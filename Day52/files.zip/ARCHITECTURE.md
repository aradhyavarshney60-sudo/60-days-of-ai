# BuildPath — Architecture

**Status:** Approved — Day 2
**Source of truth:** BuildPath PRD v1.0, Implementation Blueprint (Day 2 section)

This document defines the technical architecture for BuildPath v1.0. It implements — and does not alter — the scope defined in the PRD.

---

## 1. Tech Stack

| Layer | Choice | Why |
|---|---|---|
| Frontend | React + Vite + Tailwind CSS | Fast local dev, strong AI-assisted coding support, no hand-written CSS under time pressure. |
| Backend | Supabase client SDK (direct from frontend) + 2 Vercel serverless functions | Supabase covers CRUD + auth with Row-Level Security. Serverless functions exist *only* to keep the Gemini API key server-side. No custom Express/Node backend. |
| Database | Supabase Postgres (free tier) | Relational model fits the 1 user → 1 project → many tasks structure exactly. |
| Authentication | Supabase Auth (email/password) | Built-in, zero extra services, matches PRD (no OAuth in v1.0). |
| AI Model/API | Google Gemini API (free tier) | Free key with no credit card, sufficient quota for capstone-scale usage, reliable structured JSON output. |
| Hosting | Vercel (free tier) | Hosts the static frontend and the 2 serverless functions on one platform. |
| Supporting libraries | `supabase-js`, `react-router-dom`, `zod` | `zod` validates AI-generated JSON before it ever reaches the database. |

**Explicitly not used:** custom Node/Express server, OAuth providers, paid tiers of any service, a second hosting provider, a message queue, or any caching layer. All are unnecessary at this scale and would violate the PRD's "no unnecessary backend/infrastructure complexity" constraint.

---

## 2. Component Diagram

```mermaid
graph TD
    U["User's Browser<br/>React SPA (Vite build)"]
    V["Vercel<br/>Static Hosting + 2 Serverless Functions"]
    S[("Supabase<br/>Postgres DB + Auth")]
    G["Google Gemini API"]

    U -->|"Direct DB reads/writes via supabase-js (RLS enforced)"| S
    U -->|"Auth: signup / login / logout"| S
    U -->|"POST /api/generate-plan, POST /api/next-step"| V
    V -->|"Server-side call, key never exposed to browser"| G
    V -->|"Insert/update rows as the authenticated user"| S
```

**Design principle:** simple CRUD (reading tasks, toggling completion) goes straight from browser to Supabase. Anything touching Gemini must pass through a serverless function, because the API key cannot live in client-side code.

---

## 3. Data Flow — Generate Plan

```mermaid
sequenceDiagram
    participant U as User (Browser)
    participant F as React Frontend
    participant V as Vercel Function /api/generate-plan
    participant G as Gemini API
    participant S as Supabase (DB)

    U->>F: Submits intake form (idea, skill, time, prefs)
    F->>V: POST /api/generate-plan + Supabase auth token
    V->>V: Verify token (Supabase JWT)
    V->>G: Structured prompt with intake data
    G-->>V: JSON: phases + tasks
    V->>V: Validate JSON shape (zod)
    alt JSON invalid
        V-->>F: 502 error — "plan generation failed, retry"
    else JSON valid
        V->>S: Insert into projects + tasks (as the user)
        S-->>V: Rows created
        V-->>F: 201 + created project & tasks
        F-->>U: Redirect to Dashboard
    end
```

---

## 4. Data Flow — What's My Next Step?

```mermaid
sequenceDiagram
    participant U as User (Browser)
    participant F as React Frontend
    participant V as Vercel Function /api/next-step
    participant G as Gemini API
    participant S as Supabase (DB)

    U->>F: Clicks "What's my next step?" (+ optional note)
    F->>S: Fetch current task list & completion state
    S-->>F: Task list
    F->>V: POST /api/next-step (tasks, user_note)
    V->>G: Prompt: task state + note → next step
    G-->>V: JSON: next_task_id, explanation, adjustment_note
    V->>S: Insert into next_step_logs (optional, for history)
    V-->>F: Response payload
    F-->>U: Renders Next Step panel
```

---

## 5. AI Interaction Flow (shared shape for both AI endpoints)

```mermaid
graph LR
    A[Input data<br/>intake or task state] --> B[Prompt template<br/>+ strict JSON schema instruction]
    B --> C[Gemini API call]
    C --> D{Valid JSON?}
    D -->|No| E[Return error to frontend<br/>user can retry]
    D -->|Yes| F[Save relevant data to Supabase]
    F --> G[Return result to frontend]
```

**Design principle:** the AI is used for exactly two narrow, well-defined jobs — generating a structured plan, and giving lightweight next-step guidance. It is never used as an open-ended chat interface. This matches the PRD's explicit exclusion of "full conversational AI tutor / open-ended chat."

---

## 6. Authentication Flow

Handled entirely by Supabase Auth — no custom code required beyond calling the SDK.

```mermaid
sequenceDiagram
    participant U as User
    participant F as React Frontend
    participant S as Supabase Auth

    U->>F: Enters email + password (Sign Up)
    F->>S: supabase.auth.signUp()
    S-->>F: Session + JWT
    F->>F: Store session (supabase-js handles this)
    F-->>U: Redirect to Intake or Dashboard

    U->>F: Enters email + password (Log In)
    F->>S: supabase.auth.signInWithPassword()
    S-->>F: Session + JWT
    F-->>U: Redirect based on project state
```

---

## 7. External Services

| Service | Purpose | Tier |
|---|---|---|
| Supabase | Postgres database + Auth | Free |
| Google Gemini API | AI plan generation + next-step guidance | Free |
| Vercel | Static hosting + serverless functions | Free |

No other external services are used in v1.0.

---

## 8. Explicitly Deferred (do not build now)

Per PRD Section 5 (Scope): multi-project support, deep skill graphs, resource curation libraries, team collaboration, OAuth login, paid infrastructure, native mobile apps. None of these affect today's architecture.
