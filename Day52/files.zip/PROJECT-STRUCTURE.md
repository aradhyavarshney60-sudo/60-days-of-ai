# BuildPath — Project Structure

**Status:** Approved — Day 2. This is the folder structure Day 3 (Setup) will scaffold.

```
buildpath/
├── api/                          # Vercel serverless functions (the ONLY backend code)
│   ├── generate-plan.js          # POST /api/generate-plan — calls Gemini, validates, saves plan
│   └── next-step.js              # POST /api/next-step — calls Gemini, returns guidance
│
├── src/                          # React frontend (Vite)
│   ├── main.jsx                  # App entry point
│   ├── App.jsx                   # Route definitions (react-router-dom)
│   │
│   ├── pages/                    # One file per screen (matches UI-WIREFRAMES.md)
│   │   ├── AuthPage.jsx          # Screen 1 — Sign up / Log in
│   │   ├── IntakePage.jsx        # Screen 2 — Project intake form
│   │   ├── LoadingPage.jsx       # Screen 3 — Plan generation wait state
│   │   ├── DashboardPage.jsx     # Screen 4 — Task checklist + progress
│   │   └── NextStepPanel.jsx     # Screen 5 — Next-step guidance (modal or route)
│   │
│   ├── components/                # Reusable UI pieces
│   │   ├── TaskItem.jsx           # Single checklist row, incl. skill-gap badge
│   │   ├── ProgressBar.jsx
│   │   └── LoadingSpinner.jsx
│   │
│   ├── lib/
│   │   ├── supabaseClient.js     # Initializes supabase-js with public anon key
│   │   └── api.js                # Thin wrapper for calling /api/generate-plan, /api/next-step
│   │
│   ├── hooks/
│   │   ├── useAuth.js            # Wraps Supabase auth state
│   │   └── useProject.js         # Fetches current project + tasks
│   │
│   └── styles/
│       └── index.css             # Tailwind entry
│
├── DESIGN.md                     # Day 2 design notes (from Blueprint)
├── ARCHITECTURE.md               # This design's architecture doc
├── SCHEMA.md                     # Database schema doc
├── API.md                        # API contract doc
├── UI-WIREFRAMES.md              # UI/UX doc
├── PROJECT-STRUCTURE.md          # This file
│
├── .env.local                    # Local secrets (Gemini key, Supabase URL/anon key) — gitignored
├── .env.example                  # Template showing required env vars, no real values
├── .gitignore
├── index.html                    # Vite entry HTML
├── package.json
├── tailwind.config.js
├── vite.config.js
└── README.md                     # Setup + run instructions
```

---

## Folder Responsibilities

| Folder | Responsibility |
|---|---|
| `api/` | **The entire custom backend.** Two functions only. Anything that needs the Gemini API key lives here and nowhere else. |
| `src/pages/` | One file per screen from `UI-WIREFRAMES.md`. Pages own layout and data-fetching for that screen; they compose components. |
| `src/components/` | Small, reusable, presentation-focused pieces used across pages. |
| `src/lib/` | Thin clients — Supabase init and the fetch wrapper for the two serverless functions. No business logic here. |
| `src/hooks/` | Shared stateful logic (auth state, current project/tasks) so pages stay simple. |
| Root `*.md` files | Living documentation, committed to the repo so every future day (and every fresh AI conversation) has full context without re-explaining the project. |

---

## Where Future Code Will Live (Days 4–7 preview, no action needed today)

- **Day 4 (Auth & Intake):** `AuthPage.jsx`, `IntakePage.jsx`, `useAuth.js`, `supabaseClient.js`
- **Day 5 (AI Plan Generation):** `api/generate-plan.js`, `LoadingPage.jsx`, `DashboardPage.jsx` (initial render)
- **Day 6 (Task Tracking):** `TaskItem.jsx`, `ProgressBar.jsx`, `useProject.js`
- **Day 7 (Next Step & Learning Gaps):** `api/next-step.js`, `NextStepPanel.jsx`, skill-gap badge in `TaskItem.jsx`

---

## Why This Structure Fits the MVP

- **Flat and shallow** — no nested feature-module architecture, no state-management library (React state + hooks is enough at this scale).
- **One backend folder, two files** — matches the architecture decision that Supabase handles CRUD directly; there is nothing to over-organize.
- **Docs live in the repo root** — so Day 3 onward, a fresh AI conversation can be pointed at these files instead of re-deriving decisions.
- **No premature abstraction** — no generic "services" layer, no GraphQL, no separate API client package. Everything maps directly to a screen or a serverless function, which keeps a solo 10-day build easy to reason about.
