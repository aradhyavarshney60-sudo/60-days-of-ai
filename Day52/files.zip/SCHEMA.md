# BuildPath — Database Schema

**Status:** Approved — Day 2
**Database:** Supabase Postgres (free tier)
**Core rule enforced at the DB level:** one active project per user (PRD Section 5)

---

## Entity-Relationship Diagram

```mermaid
erDiagram
    PROFILES ||--o{ PROJECTS : owns
    PROJECTS ||--o{ TASKS : contains
    PROJECTS ||--o{ NEXT_STEP_LOGS : has

    PROFILES {
        uuid id PK
        text email
        timestamptz created_at
    }
    PROJECTS {
        uuid id PK
        uuid user_id FK "unique — enforces one active project per user"
        text idea_text
        text skill_level
        text time_available
        text preferences
        timestamptz created_at
    }
    TASKS {
        uuid id PK
        uuid project_id FK
        text phase
        text title
        text description
        boolean is_complete
        int order_index
        boolean requires_skill
        text skill_reason
    }
    NEXT_STEP_LOGS {
        uuid id PK
        uuid project_id FK
        text user_note
        text ai_response
        timestamptz created_at
    }
```

---

## Table: `profiles`

Mirrors `auth.users` (Supabase creates `auth.users` automatically; this table holds app-specific profile data). Populated via a trigger on signup.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | uuid | PK, references `auth.users.id` | Same id as the Supabase auth user |
| `email` | text | not null | Copied from auth for convenience/display |
| `created_at` | timestamptz | default `now()` | |

---

## Table: `projects`

The single active project per user. **v1.0 constraint: `user_id` has a UNIQUE constraint**, so a user physically cannot have two rows — starting a new project requires deleting/replacing the existing one (future UX, not built in v1.0 per PRD).

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | uuid | PK, default `gen_random_uuid()` | |
| `user_id` | uuid | FK → `profiles.id`, **UNIQUE**, not null | Enforces "one active project per user" |
| `idea_text` | text | not null | Raw project idea from intake |
| `skill_level` | text | not null | e.g. "beginner", "intermediate", "advanced" |
| `time_available` | text | not null | e.g. "3-4 hrs/day" |
| `preferences` | text | nullable | Optional tech preferences / constraints |
| `created_at` | timestamptz | default `now()` | |

---

## Table: `tasks`

Belongs to exactly one project. Ordered within each phase by `order_index`.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | uuid | PK, default `gen_random_uuid()` | |
| `project_id` | uuid | FK → `projects.id`, not null, `ON DELETE CASCADE` | |
| `phase` | text | not null | e.g. "Setup", "Core Feature", "Testing" |
| `title` | text | not null | Short task name |
| `description` | text | nullable | Longer instruction |
| `is_complete` | boolean | default `false` | Drives progress tracking |
| `order_index` | int | not null | Determines display/build order |
| `requires_skill` | boolean | default `false` | Drives learning-gap flag |
| `skill_reason` | text | nullable | Brief explanation shown when `requires_skill = true` |

---

## Table: `next_step_logs` (optional — build only if time allows, per Blueprint)

A lightweight history of "what's my next step" interactions. Not required for the core loop to function; the feature works without persisting history. Include only if Day 6-7 time allows.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| `id` | uuid | PK, default `gen_random_uuid()` | |
| `project_id` | uuid | FK → `projects.id`, not null, `ON DELETE CASCADE` | |
| `user_note` | text | nullable | What the user said they were stuck on |
| `ai_response` | text | not null | The explanation returned |
| `created_at` | timestamptz | default `now()` | |

---

## Row-Level Security (RLS)

RLS must be enabled on all four tables. Policy pattern (applied per table):

```sql
-- Example for projects; repeat the pattern for tasks (via project_id join)
-- and next_step_logs (via project_id join)

alter table projects enable row level security;

create policy "Users can view their own project"
  on projects for select
  using (auth.uid() = user_id);

create policy "Users can insert their own project"
  on projects for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own project"
  on projects for update
  using (auth.uid() = user_id);
```

For `tasks` and `next_step_logs`, the policy checks ownership through a join on `project_id -> projects.user_id`, since these tables don't have `user_id` directly:

```sql
create policy "Users can view their own tasks"
  on tasks for select
  using (
    exists (
      select 1 from projects
      where projects.id = tasks.project_id
      and projects.user_id = auth.uid()
    )
  );
```

This is what allows the frontend to talk to Supabase directly and safely — a user can never read or modify another user's data, even with the anon public key.

---

## Mapping to PRD User Stories

| User Story (PRD Section 7) | Schema Support |
|---|---|
| Describe project idea | `projects.idea_text` |
| Guided intake (skill, time, prefs) | `projects.skill_level`, `time_available`, `preferences` |
| View personalized, ordered plan | `tasks.phase` + `order_index` |
| Check off tasks, progress persists | `tasks.is_complete` |
| "What's my next step?" | Read from `tasks`, optional write to `next_step_logs` |
| Learning-gap flag | `tasks.requires_skill`, `tasks.skill_reason` |
| Return later, same state | All tables persist per user via `user_id`/`project_id` chain |

---

## Constraints Summary

- `projects.user_id` — UNIQUE (one active project per user)
- All FKs use `ON DELETE CASCADE` where the child has no meaning without the parent
- RLS enabled on every table — no table is publicly readable/writable
