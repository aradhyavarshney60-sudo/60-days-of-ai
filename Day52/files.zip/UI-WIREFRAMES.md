# BuildPath — UI & User Flow

**Status:** Approved — Day 2 (low-fidelity — no visual design yet)

---

## User Flow Diagram

```mermaid
graph TD
    A[Landing Page] --> B{Has account?}
    B -->|No| C[Sign Up]
    B -->|Yes| D[Log In]
    C --> E[Intake Form]
    D --> F{Has active project?}
    F -->|No| E[Intake Form]
    F -->|Yes| G[Dashboard]
    E --> H[Loading: Generating Plan]
    H --> G
    G --> I[Toggle task complete]
    G --> J["Click 'What's my next step?'"]
    J --> K[Next Step Panel]
    K --> G
    G --> L{Task flagged requires_skill?}
    L -->|Yes| M[Learning-gap note shown inline on task]
    L -->|No| G
```

**Key routing rule:** after login, the app checks whether the user already has a project row. If yes → Dashboard. If no → Intake. This is the mechanism that enforces "one active project per user" in the UI layer, matching the DB constraint.

---

## Screen Flow

```mermaid
graph LR
    S1[1. Auth Screen] --> S2[2. Intake Form]
    S2 --> S3[3. Loading State]
    S3 --> S4[4. Dashboard]
    S4 --> S5[5. Next Step Panel]
    S5 --> S4
```

---

## Screen 1 — Auth Screen

**Responsibility:** Sign up or log in. Nothing else happens here.

```
 ┌────────────────────────────────────────┐
 │              BuildPath                 │
 │   Turn your project idea into a plan   │
 │                                          │
 │   [ Email                            ]  │
 │   [ Password                         ]  │
 │                                          │
 │            [   Log In   ]               │
 │                                          │
 │   Don't have an account? Sign up ->     │
 └────────────────────────────────────────┘
```

- Toggling "Sign up" swaps the button label and calls `signUp` instead of `signInWithPassword`.
- On success, frontend checks for an existing project and routes accordingly (see User Flow).

---

## Screen 2 — Intake Form

**Responsibility:** Collect the four inputs `POST /api/generate-plan` needs. This is the *only* place project idea and preferences are captured.

```
 ┌────────────────────────────────────────┐
 │  What do you want to build?             │
 │  [ Text area: describe your idea     ]  │
 │  [                                   ]  │
 │                                          │
 │  Your current skill level               │
 │  ( ) Beginner  ( ) Intermediate  ( ) Adv │
 │                                          │
 │  Time available per day                 │
 │  [ e.g. 3-4 hrs/day                  ]  │
 │                                          │
 │  Tech preferences / constraints (opt.)  │
 │  [                                   ]  │
 │                                          │
 │           [ Generate My Plan ]          │
 └────────────────────────────────────────┘
```

- Submit button disabled until required fields are filled.
- On submit → calls `/api/generate-plan` → navigates to Loading State.

---

## Screen 3 — Loading State

**Responsibility:** Simple wait state while Gemini generates the plan (typically several seconds).

```
 ┌────────────────────────────────────────┐
 │                                          │
 │           [ spinner/animation ]         │
 │                                          │
 │     Building your personalized plan…    │
 │                                          │
 └────────────────────────────────────────┘
```

- On success → Dashboard. On failure → error message with a "Try Again" button that re-submits the same intake data.

---

## Screen 4 — Dashboard

**Responsibility:** The core screen. Shows the plan as a checklist, tracks progress, surfaces learning-gap flags, and is the entry point to "next step" guidance.

```
 ┌────────────────────────────────────────┐
 │  Your Project: "Habit tracker app"      │
 │  Progress: ███████░░░░░░  47%           │
 │                                          │
 │  ── Phase: Setup ──                     │
 │  [x] Initialize project repo            │
 │  [x] Set up database schema             │
 │  [ ] Configure auth        ⚠ needs skill │
 │      "You'll need basic JWT knowledge"  │
 │                                          │
 │  ── Phase: Core Feature ──              │
 │  [ ] Build habit list UI                │
 │  [ ] Build streak calculation logic     │
 │                                          │
 │        [ What's my next step? ]         │
 └────────────────────────────────────────┘
```

- Tasks grouped by `phase`, ordered by `order_index`.
- Checkbox click → optimistic UI update → `supabase.from('tasks').update(...)`.
- `requires_skill = true` tasks show the ⚠ badge and `skill_reason` inline, directly under the task — no separate screen needed.
- "What's my next step?" button opens the Next Step Panel (screen 5), passing current task state.

---

## Screen 5 — Next Step Panel

**Responsibility:** Show AI guidance for what to do next, optionally informed by a user note about what's confusing them.

```
 ┌────────────────────────────────────────┐
 │  What's my next step?                   │
 │                                          │
 │  Optional: what's confusing you?        │
 │  [                                   ]  │
 │           [ Ask BuildPath ]             │
 │  ──────────────────────────────────    │
 │  Next: Configure auth                   │
 │                                          │
 │  "Focus on getting basic email/password │
 │  login working before adding sessions.  │
 │  Supabase handles most of this for you."│
 │                                          │
 │  Tip: Review Supabase Auth quickstart    │
 │                                          │
 │            [ Back to Dashboard ]        │
 └────────────────────────────────────────┘
```

- Can be a modal/overlay on top of the Dashboard rather than a full route — implementation detail for Day 6-7, not a design blocker today.
- Calls `/api/next-step` with current tasks + optional note.

---

## Navigation Summary

| From | Action | To |
|---|---|---|
| Auth Screen | Successful login, no project | Intake Form |
| Auth Screen | Successful login, has project | Dashboard |
| Intake Form | Submit | Loading State |
| Loading State | Plan generated | Dashboard |
| Loading State | Generation failed | Intake Form (retry) |
| Dashboard | Click "What's my next step?" | Next Step Panel |
| Next Step Panel | Click "Back to Dashboard" | Dashboard |

No other screens exist in v1.0 — this matches the PRD's tightly scoped feature set.
